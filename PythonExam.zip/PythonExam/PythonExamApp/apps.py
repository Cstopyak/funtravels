from django.apps import AppConfig


class PythonexamappConfig(AppConfig):
    name = 'PythonExamApp'
